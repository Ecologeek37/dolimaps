var lat = 48.852969;
var lon = 2.349903;
var macarte = null;
function initMap() {
    macarte = L.map("map").setView([lat, lon], 11);
    L.tileLayer("https://{s}.tile.openstreetmap.fr/osmfr/{z}/{x}/{y}.png", {
        attribution: "",
        minZoom: 1,
        maxZoom: 20
    }).addTo(macarte);
}
window.onload = function(){
    initMap(); 
};